CREATE DEFINER = root@localhost VIEW base_category_view AS
SELECT `gmall`.`base_category3`.`id`   AS `id`,
       `gmall`.`base_category1`.`id`   AS `category1_id`,
       `gmall`.`base_category1`.`name` AS `category1_name`,
       `gmall`.`base_category2`.`id`   AS `category2_id`,
       `gmall`.`base_category2`.`name` AS `category2_name`,
       `gmall`.`base_category3`.`id`   AS `category3_id`,
       `gmall`.`base_category3`.`name` AS `category3_name`
FROM ((`gmall`.`base_category1` JOIN `gmall`.`base_category2` ON ((`gmall`.`base_category1`.`id` =
                                                                   `gmall`.`base_category2`.`category1_id`)))
         JOIN `gmall`.`base_category3` ON ((`gmall`.`base_category2`.`id` = `gmall`.`base_category3`.`category2_id`)));

